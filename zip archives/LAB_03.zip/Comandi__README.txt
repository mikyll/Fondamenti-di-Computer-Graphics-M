
mouse drag -> rotazione trackball
mouse wheel -> zoom in & out
ctrl + mouse wheel -> traslazione camera orizzontale
shift + mouse wheel -> traslazione camera verticale

Freccia sinistra: seleziona oggetto precedente.
Freccia destra: seleziona oggetto successivo.

'g'= modalit� traslazione 
's'= modalit� scalatura 
'r'= modalit� rotazione

'w'= WCS trasformation
'o'= OCS trasformation // default

Per selezionare un asse premere 'x' 'y' 'z', X � di default

Per applicare la trasformazione usare la rotella del mouse.
Cliccare col mouse disabilita la modalit� di trasformazione.

