The meshes inside this dir are intended for internal testing only.
They were taken from various public repositories.
For more details on the licensing of the various models check the original sites.
 
Visual computing LAb models:
18/10/2005  12:37           268,845 bunny10k.ply
18/10/2005  12:37            32,676 bunny2.ply
22/12/2005  12:20             1,673 T.ply
13/12/2005  22:02               475 TextureDouble.ply
23/12/2005  10:59            80,084 knot_max_simplified.STL

The following Models are provided by courtesy of the
AIM@SHAPE Shape Repository ( http://shapes.aim-at-shape.net )

23/12/2005  09:37           679,497 sharp_sphere.off
23/12/2005  09:37           333,765 trim-star.off
23/12/2005  09:37           334,305 twirl.off
22/12/2005  16:39           443,012 elephant.ply
23/12/2005  09:37           134,014 block.off
22/12/2005  16:39           443,924 brain.ply
23/12/2005  09:37           342,006 casting.off
22/12/2005  16:39           554,780 hippo.ply


The following model is provided by courtesy of Cyberware 
(www.cyberware.com)

24/11/2005  18:07           285,329 screwdriver.ply

The following model is provided by courtesy of the 
TMF repository of the San Diego Supercomputer Center  
http://www.sdsc.edu/tmf/Repository/database.html

22/12/2005  12:12           322,184 conrod.stl

The following model is provided by courtesy of D-Scupltor (http://www.d-vw.com )

10/08/2001  11:24 AM            35,429 radio.3ds
08/02/2001  11:43 AM           281,715 sub.obj
